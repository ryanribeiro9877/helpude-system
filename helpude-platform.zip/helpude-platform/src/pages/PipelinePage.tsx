import { PipelineBoard } from '@/components/pipeline/PipelineBoard';

export function PipelinePage() {
  return <PipelineBoard />;
}
