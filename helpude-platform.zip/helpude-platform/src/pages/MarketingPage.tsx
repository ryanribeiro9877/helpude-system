import { MarketingConfig } from '@/components/marketing/MarketingConfig';

export function MarketingPage() {
  return <MarketingConfig />;
}
